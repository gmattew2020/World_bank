
function sendMessage() {
    const input = document.getElementById('chat-input');
    const chatBox = document.getElementById('chat-box');
    const message = input.value.trim();
    if (message) {
        const msgElem = document.createElement('div');
        msgElem.textContent = "You: " + message;
        chatBox.appendChild(msgElem);
        input.value = '';
        chatBox.scrollTop = chatBox.scrollHeight;
    }
}

window.onload = function() {
    fetch('https://api.exchangerate-api.com/v4/latest/USD')
        .then(response => response.json())
        .then(data => {
            const ratesDiv = document.getElementById('rates');
            let html = '<ul>';
            const currencies = ['EUR', 'GBP', 'JPY', 'INR', 'CNY'];
            currencies.forEach(cur => {
                html += `<li>1 USD = ${data.rates[cur]} ${cur}</li>`;
            });
            html += '</ul>';
            ratesDiv.innerHTML = html;
        })
        .catch(() => {
            document.getElementById('rates').textContent = 'Unable to load exchange rates.';
        });
};
